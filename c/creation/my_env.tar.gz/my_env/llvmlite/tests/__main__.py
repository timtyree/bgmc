from llvmlite.tests import main

main()
